// ==========================================================================
// BIẾN TOÀN CỤC
// ==========================================================================
let currentMenu = null;
let closeTimeout = null;

// ==========================================================================
// KHỞI TẠO CHUNG KHI TRANG TẢI XONG
// ==========================================================================
window.onload = function () {
    initMegaMenu();
    initSearchOverlay();
    initProductCardInteractivity();
    initScrollEffect();
    initCustomSelect();
    initViewSwitching();
    initPoloCategoryTabs();
    initSweatCategoryTabs();
    initQuanCategoryTabs();
    initAoKhoacCategoryTabs();
    initDamvayCategoryTabs();
};


// ==========================================================================
// TIỆN ÍCH DÙNG CHUNG
// ==========================================================================

// Tạo SVG dấu tick — dùng cho Sort, Custom Select, và các option
function taoSvgTick() {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'check-icon');
    svg.setAttribute('width', '16'); svg.setAttribute('height', '16');
    svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor'); svg.setAttribute('stroke-width', '2');
    const poly = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
    poly.setAttribute('points', '20 6 9 17 4 12');
    svg.appendChild(poly);
    return svg;
}

// Chọn 1 option trong nhóm: xóa active + tick cũ, thêm mới
function chonOption(options, selected) {
    options.forEach(function (opt) {
        opt.classList.remove('active');
        const tick = opt.querySelector('.check-icon');
        if (tick) tick.remove();
    });
    selected.classList.add('active');
    selected.appendChild(taoSvgTick());
}

// Đồng bộ active cho nhóm tab theo attr (vd: data-view, href)
function syncActive(selector, attr, value) {
    document.querySelectorAll(selector).forEach(function (el) {
        el.classList.toggle('active', el.getAttribute(attr) === value);
    });
}

// Gắn sự kiện click cho nhiều nhóm tab, gọi chung 1 handler
function attachCategoryTabListeners(selectors, handlerName) {
    selectors.forEach(function (selector) {
        document.querySelectorAll(selector).forEach(function (tab) {
            tab.addEventListener('click', function (e) {
                e.preventDefault();
                if (typeof window[handlerName] === 'function') {
                    window[handlerName](this.getAttribute('href'));
                }
            });
        });
    });
}


// ==========================================================================
// MODULE 1: MEGA MENU (HOVER ĐỂ MỞ)
// ==========================================================================
function initMegaMenu() {
    document.querySelectorAll('.nav-link').forEach(function (link) {
        link.addEventListener('mouseenter', function () { openMegaMenu(this.getAttribute('data-menu')); });
        link.addEventListener('mouseleave', startCloseTimeout);
    });

    document.querySelectorAll('.mega-menu').forEach(function (menu) {
        menu.addEventListener('mouseenter', cancelCloseTimeout);
        menu.addEventListener('mouseleave', startCloseTimeout);
    });
}

function openMegaMenu(menuType) {
    cancelCloseTimeout();
    if (currentMenu && currentMenu !== menuType) closeMegaMenu();
    currentMenu = menuType;

    ['.nav-link', '.mega-menu'].forEach(function (sel) {
        document.querySelectorAll(sel).forEach(function (el) {
            el.classList.toggle('active', el.getAttribute('data-menu') === menuType);
        });
    });
}

function closeMegaMenu() {
    document.querySelectorAll('.mega-menu, .nav-link').forEach(function (el) {
        el.classList.remove('active');
    });
    currentMenu = null;
}

function startCloseTimeout() {
    cancelCloseTimeout();
    closeTimeout = setTimeout(closeMegaMenu, 200);
}

function cancelCloseTimeout() {
    if (closeTimeout) { clearTimeout(closeTimeout); closeTimeout = null; }
}


// ==========================================================================
// MODULE 2: LỚP PHỦ TÌM KIẾM (SEARCH OVERLAY)
// ==========================================================================
function initSearchOverlay() {
    const overlay = document.getElementById('search-overlay');
    if (!overlay) return;
    const input = overlay.querySelector('.search-input-real');

    document.querySelectorAll('a[href="#search-overlay"]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            closeMegaMenu();
            overlay.classList.add('active');
            setTimeout(function () { if (input) input.focus(); }, 300);
        });
    });

    overlay.querySelectorAll('.search-action-btn').forEach(function (btn) {
        btn.addEventListener('click', function (e) { e.preventDefault(); closeSearchOverlay(); });
    });

    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeSearchOverlay(); });
    overlay.addEventListener('click', function (e) { if (e.target === overlay) closeSearchOverlay(); });
}

function closeSearchOverlay() {
    const overlay = document.getElementById('search-overlay');
    if (!overlay) return;
    const input = overlay.querySelector('.search-input-real');
    overlay.classList.remove('active');
    if (input) { input.blur(); input.value = ''; }
}


// ==========================================================================
// MODULE 3: TAB CATEGORY BONG BÓNG TRÒN
// ==========================================================================
document.addEventListener('click', function (e) {
    const tab = e.target.closest('.cat-tab');
    if (!tab) return;
    const container = tab.closest('.category-tabs-scroll');
    if (!container) return;
    container.querySelectorAll('.cat-tab').forEach(function (t) { t.classList.remove('active'); });
    tab.classList.add('active');
});


// ==========================================================================
// MODULE 4: THANH LỌC SẢN PHẨM (FILTER BAR DROPDOWNS)
// ==========================================================================
const danhSachDropdown = [
    { nutId: 'btn-availability', menuId: 'dropdown-availability' },
    { nutId: 'btn-gender',       menuId: 'dropdown-gender'       },
    { nutId: 'btn-promo',        menuId: 'dropdown-promo'        },
    { nutId: 'btn-size',         menuId: 'dropdown-size'         },
    { nutId: 'btn-color',        menuId: 'dropdown-color'        },
    { nutId: 'btn-price',        menuId: 'dropdown-price'        }
];

function dongTatCaDropdown() {
    danhSachDropdown.forEach(function (item) {
        const nut = document.getElementById(item.nutId);
        const menu = document.getElementById(item.menuId);
        if (nut) nut.classList.remove('active');
        if (menu) menu.classList.remove('show');
    });
}

danhSachDropdown.forEach(function (item) {
    const nut = document.getElementById(item.nutId);
    const menu = document.getElementById(item.menuId);
    if (!nut || !menu) return;

    nut.addEventListener('click', function (e) {
        e.stopPropagation();
        const dangMo = menu.classList.contains('show');
        dongTatCaDropdown();
        if (!dangMo) { nut.classList.add('active'); menu.classList.add('show'); }
    });

    menu.addEventListener('click', function (e) { e.stopPropagation(); });
});

document.querySelectorAll('.dropdown-close').forEach(function (btn) {
    btn.addEventListener('click', function (e) { e.stopPropagation(); dongTatCaDropdown(); });
});

document.addEventListener('click', dongTatCaDropdown);


// ==========================================================================
// MODULE 5: DROPDOWN SẮP XẾP (SORT DROPDOWN)
// ==========================================================================
function initSortDropdown() {
    const sortBtn  = document.getElementById('sort-dropdown-btn');
    const sortMenu = document.getElementById('sort-dropdown-menu');
    const sortText = document.getElementById('sort-text');
    if (!sortBtn || !sortMenu) return;

    sortBtn.addEventListener('click', function (e) { e.stopPropagation(); sortMenu.classList.toggle('show'); });
    sortMenu.addEventListener('click', function (e) { e.stopPropagation(); });

    const options = sortMenu.querySelectorAll('.sort-option');
    options.forEach(function (option) {
        option.addEventListener('click', function () {
            chonOption(options, this);
            if (sortText) sortText.textContent = this.getAttribute('data-text');
            sortMenu.classList.remove('show');
        });
    });

    document.addEventListener('click', function (e) {
        if (!e.target.closest('.sort-dropdown-wrapper')) sortMenu.classList.remove('show');
    });
}
initSortDropdown();


// ==========================================================================
// MODULE 6: THẺ SẢN PHẨM (PRODUCT CARDS)
// ==========================================================================
function initProductCardInteractivity() {

    // Đồng bộ ảnh + swatch theo index
    function activateByIndex(card, index) {
        card.querySelectorAll('.product-color-img').forEach(function (img, i) {
            img.classList.toggle('active', i === index);
        });
        card.querySelectorAll('.swatch').forEach(function (sw, i) {
            sw.classList.toggle('active', i === index);
        });
    }

    // Hover/click swatch chuyển màu
    document.querySelectorAll('.product-card .swatch').forEach(function (swatch) {
        function activate() {
            const card = swatch.closest('.product-card');
            if (!card) return;
            const swatches = [...card.querySelectorAll('.swatch')];
            activateByIndex(card, swatches.indexOf(swatch));
        }
        swatch.addEventListener('mouseenter', activate);
        swatch.addEventListener('click', function (e) { e.stopPropagation(); activate(); });
    });

    // Nút yêu thích
    document.querySelectorAll('.product-card .wishlist-btn').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation(); e.preventDefault();
            this.classList.toggle('active');
        });
    });

    // Mũi tên trái/phải chuyển ảnh — gộp 2 nút thành 1 hàm
    function navigateImage(card, direction) {
        const imgs = card.querySelectorAll('.product-color-img');
        if (imgs.length <= 1) return;
        let current = 0;
        imgs.forEach(function (img, i) { if (img.classList.contains('active')) current = i; });
        activateByIndex(card, (current + direction + imgs.length) % imgs.length);
    }

    // Gộp prev/next thành 1 vòng lặp với data-direction
    [{ sel: '.img-nav-prev', dir: -1 }, { sel: '.img-nav-next', dir: 1 }].forEach(function (item) {
        document.querySelectorAll('.product-card ' + item.sel).forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                e.stopPropagation(); e.preventDefault();
                navigateImage(this.closest('.product-card'), item.dir);
            });
        });
    });

    // Log khi click vào card
    document.querySelectorAll('.product-card').forEach(function (card) {
        card.addEventListener('click', function () {
            console.log('Xem chi tiết sản phẩm ID:', this.getAttribute('data-id'), '-', this.querySelector('.product-title').textContent);
        });
    });
}


// ==========================================================================
// MODULE 7: SCROLL STICKY EFFECT
// ==========================================================================
function initScrollEffect() {
    const SCROLL_VIEWS_TALL = ['view-polo', 'view-sweat', 'view-quandai', 'view-quanshort', 'view-aokhoac', 'view-aobp'];
    let lastScrollTop = 0;

    window.addEventListener('scroll', function () {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const nguong = SCROLL_VIEWS_TALL.some(function (cls) { return document.body.classList.contains(cls); }) ? 680 : 180;

        if (scrollTop < nguong) {
            document.body.classList.remove('scroll-up', 'scroll-down');
        } else {
            document.body.classList.toggle('scroll-down', scrollTop > lastScrollTop);
            document.body.classList.toggle('scroll-up',   scrollTop < lastScrollTop);
        }
        lastScrollTop = scrollTop;
    });
}


// ==========================================================================
// MODULE 8: CUSTOM SELECT BOX
// ==========================================================================
function initCustomSelect() {
    const wrapper = document.querySelector('.gc-select-wrapper');
    if (!wrapper) return;

    const selectBox    = wrapper.querySelector('.gc-select-box');
    const options      = wrapper.querySelectorAll('.gc-option');
    const selectedText = selectBox.querySelector('span');

    selectBox.addEventListener('click', function (e) { e.stopPropagation(); wrapper.classList.toggle('open'); });

    options.forEach(function (opt) {
        opt.addEventListener('click', function (e) {
            e.stopPropagation();
            chonOption(options, this);
            if (selectedText) selectedText.textContent = this.querySelector('span').textContent;
            wrapper.classList.remove('open');
            const view = this.getAttribute('data-view');
            if (view) switchView(view);
        });
    });

    document.addEventListener('click', function (e) {
        if (!e.target.closest('.gc-select-wrapper')) wrapper.classList.remove('open');
    });
}


// ==========================================================================
// MODULE 9: CHUYỂN ĐỔI VIEW (VIEW SWITCHING)
// ==========================================================================
const HASH_TO_VIEW = {
    '#quan-category-tabs-section': 'quan',
    '#quan-section':               'quan',
    '#quandai-category-section':   'quan',
    '#quan-jeans-section':         'quan',
    '#quan-ni-section':            'quan',
    '#quan-jogger-section':        'quan',
    '#quan-short-section':         'quan',
    '#quanshort-category-section': 'quan',
    '#quan-short-cargo-section':   'quan',
    '#quan-short-denim-section':   'quan',
    '#quan-short-the-thao-section':'quan',
    '#sweat-category-section':     'sweat',
    '#sweatshirts-section':        'sweat',
    '#hoodies-section':            'sweat',
    '#ut':                         'ut',
    '#polo':                       'polo',
    '#somi':                       'somi',
    '#all':                        'all',
    '#ao-category-tabs-section':   'ao',
    '#aokhoac-category-tabs-section': 'aokhoac',
    '#aobp-category-section':      'aobp',
};

function initViewSwitching() {
    // Gộp 3 nhóm click cùng logic vào 1 vòng lặp
    [
        { sel: '.sub-nav-tab',       attr: 'data-view' },
        { sel: '.only-all .cat-tab', attr: 'data-view' },
        { sel: '.category-item',     attr: 'data-view' },
    ].forEach(function (group) {
        document.querySelectorAll(group.sel).forEach(function (el) {
            el.addEventListener('click', function (e) {
                const view = this.getAttribute(group.attr);
                if (!view) return;
                e.preventDefault();
                switchView(view);
                if (group.sel === '.category-item') closeMegaMenu();
            });
        });
    });

    // Xử lý hash URL
    function handleHash(hash) {
        const view = HASH_TO_VIEW[hash];
        if (view) {
            switchView(view);
            if (view === 'quan' && typeof window.filterQuan === 'function') {
                window.filterQuan(hash);
            }
        }
    }

    handleHash(window.location.hash);
    window.addEventListener('hashchange', function () { handleHash(window.location.hash); });
}

function switchView(view) {
    // Reset hiển thị tất cả sections trước
    document.querySelectorAll('.products-section').forEach(function (sec) { sec.style.display = ''; });

    // Thay class view- trên body
    document.body.className = document.body.className.split(' ').filter(function (c) { return !c.startsWith('view-'); }).join(' ');
    document.body.classList.add('view-' + view);

    const row = document.querySelector('.filter-results-row');
    if (row) row.style.justifyContent = 'space-between';

    // Đồng bộ active — dùng hàm syncActive dùng chung
    syncActive('.sub-nav-tab',       'data-view', view);
    syncActive('.only-all .cat-tab', 'data-view', view);

    // Đồng bộ Custom Select
    const wrapper = document.querySelector('.gc-select-wrapper');
    if (wrapper) {
        const options      = wrapper.querySelectorAll('.gc-option');
        const selectedText = wrapper.querySelector('.gc-select-box span');
        options.forEach(function (opt) {
            const tick      = opt.querySelector('.check-icon');
            const isActive  = opt.getAttribute('data-view') === view;
            opt.classList.toggle('active', isActive);
            if (isActive) {
                if (selectedText) selectedText.textContent = opt.querySelector('span').textContent;
                if (!tick) opt.appendChild(taoSvgTick());
            } else {
                if (tick) tick.remove();
            }
        });
    }

    // Giữ nhãn nút lọc
    const filterGenderBtn = document.getElementById('btn-gender');
    if (filterGenderBtn) {
        filterGenderBtn.innerHTML = 'Giới tính > Danh mục <svg class="dropdown-arrow" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"></polyline></svg>';
    }

    // Đồng bộ filterQuan khi view thuộc nhóm quần
    const QUAN_VIEW_TO_TARGET = {
        'quan':      '#quan-category-tabs-section',
        'quandai':   '#quandai-category-section',
        'quanshort': '#quanshort-category-section'
    };
    const targetId = QUAN_VIEW_TO_TARGET[view];
    if (targetId && typeof window.filterQuan === 'function') {
        window.filterQuan(targetId);
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return; // Thoát sớm để không xử lý tiếp
    }

    // Đồng bộ filterAokhoac khi view thuộc nhóm áo khoác
    const AOKHOAC_VIEW_TO_TARGET = {
        'aokhoac': '#aokhoac-category-tabs-section',
        'aobp':    '#aobp-category-section',
        'ao':      '#ao-category-section'
    };
    const targetAokhoacId = AOKHOAC_VIEW_TO_TARGET[view];
    if (targetAokhoacId && typeof window.filterAokhoac === 'function') {
        window.filterAokhoac(targetAokhoacId);
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return; // Thoát sớm để không xử lý tiếp
    }

    // Đồng bộ filterDamvay khi view thuộc nhóm đầm váy
    const DAMVAY_VIEW_TO_TARGET = {
        'damvay': '#damvay-category-tabs-section',
        'dam':    '#dam-category-section',
        'vay':    '#vay-category-section'
    };
    const targetDamvayId = DAMVAY_VIEW_TO_TARGET[view];
    if (targetDamvayId && typeof window.filterDamvay === 'function') {
        window.filterDamvay(targetDamvayId);
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return; // Thoát sớm để không xử lý tiếp
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
}


// ==========================================================================
// MODULE 10: BỘ LỌC DANH MỤC (POLO, SWEAT, QUẦN, ÁO KHOÁC)
// ==========================================================================

// Hàm tổng quát cho Polo & Sweat
function setupCategoryFilter(tabsSelector, sectionsSelector, defaultTabId) {
    const tabs     = document.querySelectorAll(tabsSelector);
    const sections = document.querySelectorAll(sectionsSelector);

    tabs.forEach(function (tab) {
        tab.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');

            tabs.forEach(function (t) { t.classList.remove('active'); });
            this.classList.add('active');

            if (targetId === defaultTabId) {
                sections.forEach(function (sec) { sec.style.display = 'block'; });
            } else {
                sections.forEach(function (sec) { sec.style.display = 'none'; });
                const active = document.querySelector(targetId);
                if (active) active.style.display = 'block';
            }
        });
    });
}

function initPoloCategoryTabs() {
    setupCategoryFilter('#product-category-section .cat-tab', '.products-section.only-polo', '#product-category-section');
}

function initSweatCategoryTabs() {
    setupCategoryFilter('#sweat-category-section .cat-tab', '.products-section.only-sweat', '#sweat-category-section');
}


// --- QUẦN ---
const QUAN_VIEW_MAP = {
    '#quandai-category-section':   'view-quandai',
    '#quan-jeans-section':         'view-quandai',
    '#quan-ni-section':            'view-quandai',
    '#quan-jogger-section':        'view-quandai',
    '#quanshort-category-section': 'view-quanshort',
    '#quan-short-section':         'view-quanshort',
    '#quan-short-cargo-section':   'view-quanshort',
    '#quan-short-denim-section':   'view-quanshort',
    '#quan-short-the-thao-section':'view-quanshort',
};
const QUANDAI_CHILDREN   = ['#quan-jeans-section', '#quan-ni-section', '#quan-jogger-section'];
const QUANSHORT_CHILDREN = ['#quan-short-section', '#quan-short-cargo-section', '#quan-short-denim-section', '#quan-short-the-thao-section'];

window.filterQuan = function (targetId) {
    const sections = document.querySelectorAll('.products-section.only-quan');

    if (!targetId || targetId === '#quan-section' || targetId === '#quan') {
        targetId = '#quan-category-tabs-section';
    }

    // Cập nhật class view-
    const targetView = QUAN_VIEW_MAP[targetId];
    ['view-quan', 'view-quandai', 'view-quanshort'].forEach(function (cls) { document.body.classList.remove(cls); });
    document.body.classList.add(targetView || 'view-quan');

    // Ẩn/hiện thanh subnav phụ
    const subnav = document.querySelector('.subcategory-nav-wrapper-quan');
    if (subnav) subnav.classList.toggle('first-page', targetId === '#quan-category-tabs-section');

    // Đồng bộ tab bong bóng tổng
    syncActive('#quan-category-tabs-section .cat-tab', 'href', targetId);

    // Đồng bộ subnav ngang (tab cha active khi chọn con)
    document.querySelectorAll('.subcategory-nav-wrapper-quan .sub-nav-tab-quan').forEach(function (t) {
        const href = t.getAttribute('href');
        const isActive = href === targetId
            || (href === '#quandai-category-section'   && QUANDAI_CHILDREN.includes(targetId))
            || (href === '#quanshort-category-section' && QUANSHORT_CHILDREN.includes(targetId));
        t.classList.toggle('active', isActive);
    });

    // Đồng bộ tab danh mục con
    syncActive('#quandai-category-section .cat-tab',   'href', targetId);

    document.querySelectorAll('#quanshort-category-section .cat-tab').forEach(function (t) {
        const isAll = t.id === 'short-tab-all' && targetId === '#quanshort-category-section';
        t.classList.toggle('active', t.getAttribute('href') === targetId || isAll);
    });

    // Ẩn/hiện sections sản phẩm
    if (targetId === '#quan-category-tabs-section') {
        sections.forEach(function (sec) { sec.style.display = (!sec.classList.contains('only-quandai') && !sec.classList.contains('only-quanshort')) ? 'block' : 'none'; });
    } else if (targetId === '#quandai-category-section') {
        sections.forEach(function (sec) { sec.style.display = sec.classList.contains('only-quandai') ? 'block' : 'none'; });
    } else if (targetId === '#quanshort-category-section') {
        sections.forEach(function (sec) { sec.style.display = sec.classList.contains('only-quanshort') ? 'block' : 'none'; });
    } else {
        sections.forEach(function (sec) { sec.style.display = 'none'; });
        const active = document.querySelector(targetId);
        if (active) active.style.display = 'block';
    }
};

function initQuanCategoryTabs() {
    attachCategoryTabListeners([
        '#quan-category-tabs-section .cat-tab',
        '.subcategory-nav-wrapper-quan .sub-nav-tab-quan',
        '#quandai-category-section .cat-tab',
        '#quanshort-category-section .cat-tab',
    ], 'filterQuan');
}


// --- ÁO KHOÁC ---
const AOKHOAC_VIEW_MAP = {
    '#aokhoac-category-tabs-section': 'view-aokhoac',
    '#aokhoac-category-section':      'view-aokhoac',  // Thêm mapping này
    '#aobp-category-section':         'view-aobp',
    '#ao-category-section':           'view-ao',
};

window.filterAokhoac = function (targetId) {
    // Lấy TẤT CẢ sections sản phẩm áo khoác (bao gồm cả only-aobp, only-ao)
    const sections = document.querySelectorAll('.products-section.only-aokhoac, .products-section.only-aobp, .products-section.only-ao');

    if (!targetId || targetId === '#aokhoac' || targetId === '#aokhoac-category-tabs-section' || targetId === '#aokhoac-category-section') {
        targetId = '#aokhoac-category-tabs-section';
    }

    // Cập nhật class view-
    const targetView = AOKHOAC_VIEW_MAP[targetId];
    // XÓA TẤT CẢ các class view- cũ (không chỉ aokhoac)
    ['view-all', 'view-polo', 'view-ut', 'view-somi', 'view-sweat', 'view-quan', 'view-quandai', 'view-quanshort', 'view-aokhoac', 'view-aobp', 'view-ao', 'view-damvay', 'view-dam', 'view-vay'].forEach(function (cls) { 
        document.body.classList.remove(cls); 
    });
    document.body.classList.add(targetView || 'view-aokhoac');

    // Ẩn/hiện thanh subnav phụ
    const subnav = document.querySelector('.subcategory-nav-wrapper-aokhoac');
    // KHÔNG thêm first-page khi ở trang con (chỉ thêm khi ở trang chính)
    if (subnav) {
        // Xóa first-page khi vào trang phụ (aobp, ao), thêm first-page khi ở trang chính
        if (targetId === '#aokhoac-category-tabs-section') {
            subnav.classList.add('first-page');
        } else {
            subnav.classList.remove('first-page');
        }
    }

    // Đồng bộ tab
    syncActive('#aokhoac-category-tabs-section .cat-tab', 'href', targetId);
    syncActive('.subcategory-nav-wrapper-aokhoac .sub-nav-tab-aokhoac', 'href', targetId);

    // Ẩn/hiện sections sản phẩm
    if (targetId === '#aokhoac-category-tabs-section') {
        // CHỈ hiển thị sản phẩm only-aokhoac (không bao gồm aobp và ao)
        sections.forEach(function (sec) { 
            sec.style.display = sec.classList.contains('only-aokhoac') ? 'block' : 'none'; 
        });
    } else if (targetId === '#aobp-category-section') {
        // Chỉ hiển thị sản phẩm Áo Blouson & Parka
        sections.forEach(function (sec) { 
            sec.style.display = sec.classList.contains('only-aobp') ? 'block' : 'none'; 
        });
    } else if (targetId === '#ao-category-section') {
        // Chỉ hiển thị sản phẩm Áo Khoác
        sections.forEach(function (sec) { 
            sec.style.display = sec.classList.contains('only-ao') ? 'block' : 'none'; 
        });
    } else {
        sections.forEach(function (sec) { sec.style.display = 'none'; });
        const active = document.querySelector(targetId);
        if (active) active.style.display = 'block';
    }
};

function initAoKhoacCategoryTabs() {
    attachCategoryTabListeners([
        '#aokhoac-category-tabs-section .cat-tab',
        '.subcategory-nav-wrapper-aokhoac .sub-nav-tab-aokhoac'
    ], 'filterAokhoac');
}


// --- ĐẦM VÁY ---
const DAMVAY_VIEW_MAP = {
    '#damvay-category-tabs-section': 'view-damvay',
    '#dam-category-section':         'view-dam',
    '#vay-category-section':         'view-vay',
};

window.filterDamvay = function (targetId) {
    // Lấy TẤT CẢ sections sản phẩm đầm váy (bao gồm cả only-dam, only-vay)
    const sections = document.querySelectorAll('.products-section.only-damvay, .products-section.only-dam, .products-section.only-vay');

    if (!targetId || targetId === '#damvay' || targetId === '#damvay-category-tabs-section' || targetId === '#damvay-category-section') {
        targetId = '#damvay-category-tabs-section';
    }

    // Cập nhật class view-
    const targetView = DAMVAY_VIEW_MAP[targetId];
    // XÓA TẤT CẢ các class view- cũ (không chỉ damvay)
    ['view-all', 'view-polo', 'view-ut', 'view-somi', 'view-sweat', 'view-quan', 'view-quandai', 'view-quanshort', 'view-aokhoac', 'view-aobp', 'view-ao', 'view-damvay', 'view-dam', 'view-vay'].forEach(function (cls) { 
        document.body.classList.remove(cls); 
    });
    document.body.classList.add(targetView || 'view-damvay');

    // Ẩn/hiện thanh subnav phụ
    const subnav = document.querySelector('.subcategory-nav-wrapper-damvay');
    if (subnav) {
        if (targetId === '#damvay-category-tabs-section') {
            subnav.classList.add('first-page');  // Ẩn ở trang chính
        } else {
            subnav.classList.remove('first-page');  // Hiện ở trang con
        }
    }

    // Đồng bộ tab
    syncActive('#damvay-category-tabs-section .cat-tab', 'href', targetId);
    syncActive('.subcategory-nav-wrapper-damvay .sub-nav-tab-damvay', 'href', targetId);

    // Ẩn/hiện sections sản phẩm
    if (targetId === '#damvay-category-tabs-section') {
        // CHỈ hiển thị sản phẩm only-damvay (không bao gồm dam và vay)
        sections.forEach(function (sec) { 
            sec.style.display = sec.classList.contains('only-damvay') ? 'block' : 'none'; 
        });
    } else if (targetId === '#dam-category-section') {
        // Chỉ hiển thị sản phẩm Đầm
        sections.forEach(function (sec) { 
            sec.style.display = sec.classList.contains('only-dam') ? 'block' : 'none'; 
        });
    } else if (targetId === '#vay-category-section') {
        // Chỉ hiển thị sản phẩm Váy
        sections.forEach(function (sec) { 
            sec.style.display = sec.classList.contains('only-vay') ? 'block' : 'none'; 
        });
    } else {
        sections.forEach(function (sec) { sec.style.display = 'none'; });
        const active = document.querySelector(targetId);
        if (active) active.style.display = 'block';
    }
};

function initDamvayCategoryTabs() {
    attachCategoryTabListeners([
        '#damvay-category-tabs-section .cat-tab',
        '.subcategory-nav-wrapper-damvay .sub-nav-tab-damvay'
    ], 'filterDamvay');
}